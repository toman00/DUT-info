/* TP 19 Exercice 1 : fichier lire.h */

#ifndef LIRE_H
#define LIRE_H

void lire(char*, int);

#endif /* LIRE_H */
